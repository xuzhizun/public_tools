#ifndef SUPPORT_H_INCLUDED
#define SUPPORT_H_INCLUDED

GtkWidget* lookup_widget (GtkWidget *widget,const gchar *widget_name);


#endif // SUPPORT_H_INCLUDED
